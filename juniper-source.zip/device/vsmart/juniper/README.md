# Vsmart Joy 4 (V441A) / juniper - TWRP device tree

Target: V441A_OPN_U_B3_220216 / Android 11 / Snapdragon 665 (trinket)

This tree was reconstructed from the user's stock B3 boot.img and its stock
fstab/dynamic-partition information.

Included:
- B3 kernel/DTB prebuilt
- B3 ramdisk reference
- BoardConfig.mk
- TWRP fstab
- AndroidProducts.mk / twrp_juniper.mk
- recovery properties

IMPORTANT:
This is a device-tree/build source package, NOT a tested flashable TWRP image.
The build must be performed against a matching TWRP source tree. Do not flash
the prebuilt files directly to the phone.
