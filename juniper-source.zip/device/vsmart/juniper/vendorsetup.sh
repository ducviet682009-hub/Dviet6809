# Lunch choices are declared in AndroidProducts.mk.
# add_lunch_combo is obsolete in current Android/TWRP build systems.
