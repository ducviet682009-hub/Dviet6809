# Build recipe

1. Use a TWRP source tree compatible with Android 11 / recoveryimage.
2. Place this directory at:
   device/vsmart/juniper
3. Ensure the matching Qualcomm/trinket common tree is available.
4. The lunch choices are defined in AndroidProducts.mk; vendorsetup.sh does not use add_lunch_combo.
5. Run:
   source build/envsetup.sh
   lunch twrp_juniper-eng
   mka recoveryimage

The resulting recovery image must be tested by booting it temporarily before
writing it to a recovery partition. Do NOT flash an untested image.
