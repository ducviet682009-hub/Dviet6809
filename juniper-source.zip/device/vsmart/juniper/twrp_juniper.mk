LOCAL_PATH := device/vsmart/juniper

PRODUCT_DEVICE := juniper
PRODUCT_NAME := twrp_juniper
PRODUCT_BRAND := vsmart
PRODUCT_MODEL := Vsmart Joy 4
PRODUCT_MANUFACTURER := vsmart

PRODUCT_GMS_CLIENTID_BASE := android-vsmart
